package io.confluent.developer.springccloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCcloudMavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCcloudMavenApplication.class, args);
	}

}
