package io.confluent.developer.springccloud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCcloudMavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
